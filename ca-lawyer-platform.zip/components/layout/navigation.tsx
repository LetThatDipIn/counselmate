"use client"

import Link from "next/link"
import { useState } from "react"
import { Menu, X, Shield } from "lucide-react"

export default function Navigation() {
  const [isOpen, setIsOpen] = useState(false)

  return (
    <nav className="sticky top-0 z-50 bg-white border-b border-border">
      <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8">
        <div className="flex justify-between items-center h-16">
          <Link href="/" className="flex items-center gap-2 font-bold text-lg text-primary">
            <Shield className="w-6 h-6" />
            LegalConsult
          </Link>

          <div className="hidden md:flex items-center gap-8">
            <Link href="/professionals" className="text-text-secondary hover:text-primary transition">
              Find a Pro
            </Link>
            <Link href="/jobs" className="text-text-secondary hover:text-primary transition">
              Job Board
            </Link>
            <Link href="/sign-in" className="text-text-secondary hover:text-primary transition">
              Sign In
            </Link>
            <Link
              href="/sign-up"
              className="bg-primary text-white px-6 py-2 rounded-lg hover:bg-primary-light transition"
            >
              Get Started
            </Link>
          </div>

          <button className="md:hidden" onClick={() => setIsOpen(!isOpen)}>
            {isOpen ? <X className="w-6 h-6" /> : <Menu className="w-6 h-6" />}
          </button>
        </div>

        {isOpen && (
          <div className="md:hidden pb-4 space-y-3">
            <Link href="/professionals" className="block text-text-secondary hover:text-primary">
              Find a Pro
            </Link>
            <Link href="/jobs" className="block text-text-secondary hover:text-primary">
              Job Board
            </Link>
            <Link href="/sign-in" className="block text-text-secondary hover:text-primary">
              Sign In
            </Link>
            <Link href="/sign-up" className="block w-full bg-primary text-white px-4 py-2 rounded-lg text-center">
              Get Started
            </Link>
          </div>
        )}
      </div>
    </nav>
  )
}
