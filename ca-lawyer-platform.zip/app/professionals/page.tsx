"use client"

import Link from "next/link"
import { useState, useMemo } from "react"
import { Search, Filter, Star, MapPin, Award, DollarSign } from "lucide-react"

interface Professional {
  id: number
  name: string
  role: string
  specialization: string
  rating: number
  reviews: number
  hourlyRate: number
  location: string
  experience: number
  verified: boolean
  badge: string
}

const professionals: Professional[] = [
  {
    id: 1,
    name: "Rajesh Kumar",
    role: "Chartered Accountant",
    specialization: "Taxation & GST",
    rating: 4.9,
    reviews: 124,
    hourlyRate: 1500,
    location: "Mumbai, India",
    experience: 12,
    verified: true,
    badge: "Expert",
  },
  {
    id: 2,
    name: "Priya Singh",
    role: "Corporate Lawyer",
    specialization: "M&A & Contracts",
    rating: 4.8,
    reviews: 98,
    hourlyRate: 2000,
    location: "Delhi, India",
    experience: 10,
    verified: true,
    badge: "Top Rated",
  },
  {
    id: 3,
    name: "Amit Patel",
    role: "Tax Specialist CA",
    specialization: "International Tax",
    rating: 5.0,
    reviews: 67,
    hourlyRate: 2500,
    location: "Bangalore, India",
    experience: 15,
    verified: true,
    badge: "Expert",
  },
  {
    id: 4,
    name: "Neha Sharma",
    role: "Labor Lawyer",
    specialization: "Employment Law",
    rating: 4.7,
    reviews: 82,
    hourlyRate: 1800,
    location: "Pune, India",
    experience: 8,
    verified: true,
    badge: "Rising Star",
  },
  {
    id: 5,
    name: "Vikram Singh",
    role: "Financial Advisor CA",
    specialization: "Financial Planning",
    rating: 4.6,
    reviews: 105,
    hourlyRate: 1200,
    location: "Hyderabad, India",
    experience: 9,
    verified: true,
    badge: "Popular",
  },
  {
    id: 6,
    name: "Anaya Verma",
    role: "Real Estate Lawyer",
    specialization: "Property Law",
    rating: 4.8,
    reviews: 76,
    hourlyRate: 1600,
    location: "Chennai, India",
    experience: 11,
    verified: true,
    badge: "Trusted",
  },
]

export default function ProfessionalsPage() {
  const [searchTerm, setSearchTerm] = useState("")
  const [roleFilter, setRoleFilter] = useState("")
  const [sortBy, setSortBy] = useState("rating")

  const filteredProfessionals = useMemo(() => {
    const filtered = professionals.filter((pro) => {
      const matchesSearch =
        pro.name.toLowerCase().includes(searchTerm.toLowerCase()) ||
        pro.specialization.toLowerCase().includes(searchTerm.toLowerCase()) ||
        pro.location.toLowerCase().includes(searchTerm.toLowerCase())
      const matchesRole = !roleFilter || pro.role === roleFilter

      return matchesSearch && matchesRole
    })

    if (sortBy === "rating") {
      filtered.sort((a, b) => b.rating - a.rating)
    } else if (sortBy === "price-low") {
      filtered.sort((a, b) => a.hourlyRate - b.hourlyRate)
    } else if (sortBy === "price-high") {
      filtered.sort((a, b) => b.hourlyRate - a.hourlyRate)
    } else if (sortBy === "experience") {
      filtered.sort((a, b) => b.experience - a.experience)
    }

    return filtered
  }, [searchTerm, roleFilter, sortBy])

  const roles = ["Chartered Accountant", "Lawyer", "Tax Specialist CA", "Financial Advisor"]

  return (
    <div className="min-h-screen bg-background-light">
      {/* Search and Filter Section */}
      <section className="bg-white border-b border-border sticky top-16 z-40">
        <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8 py-6">
          <div className="space-y-4">
            <div className="flex flex-col md:flex-row gap-4">
              <div className="flex-1 flex items-center gap-2 bg-background-light px-4 py-2 rounded-lg">
                <Search className="w-5 h-5 text-text-secondary" />
                <input
                  type="text"
                  placeholder="Search by name, expertise, or location..."
                  value={searchTerm}
                  onChange={(e) => setSearchTerm(e.target.value)}
                  className="w-full bg-transparent text-text-primary outline-none"
                />
              </div>
            </div>

            <div className="flex flex-col md:flex-row gap-4 items-start md:items-center">
              <div className="flex items-center gap-2">
                <Filter className="w-5 h-5 text-text-secondary" />
                <span className="text-sm font-semibold text-text-primary">Filters:</span>
              </div>

              <select
                value={roleFilter}
                onChange={(e) => setRoleFilter(e.target.value)}
                className="px-4 py-2 rounded-lg border border-border bg-white text-text-primary"
              >
                <option value="">All Roles</option>
                {roles.map((role) => (
                  <option key={role} value={role}>
                    {role}
                  </option>
                ))}
              </select>

              <select
                value={sortBy}
                onChange={(e) => setSortBy(e.target.value)}
                className="px-4 py-2 rounded-lg border border-border bg-white text-text-primary"
              >
                <option value="rating">Highest Rated</option>
                <option value="experience">Most Experienced</option>
                <option value="price-low">Price: Low to High</option>
                <option value="price-high">Price: High to Low</option>
              </select>
            </div>
          </div>
        </div>
      </section>

      {/* Results Section */}
      <section className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8 py-12">
        <div className="mb-6">
          <h1 className="text-3xl font-bold text-text-primary">Browse Professionals</h1>
          <p className="text-text-secondary mt-2">
            {filteredProfessionals.length} verified professional{filteredProfessionals.length !== 1 ? "s" : ""} found
          </p>
        </div>

        {filteredProfessionals.length > 0 ? (
          <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-3 gap-6">
            {filteredProfessionals.map((professional) => (
              <div
                key={professional.id}
                className="bg-white rounded-lg shadow-sm border border-border p-6 hover:shadow-lg hover:border-primary transition-all"
              >
                <div className="flex items-start justify-between mb-4">
                  <div className="w-14 h-14 bg-gradient-to-br from-primary to-primary-light rounded-full flex items-center justify-center text-white font-bold text-lg">
                    {professional.name.charAt(0)}
                  </div>
                  {professional.verified && (
                    <div className="bg-success text-white px-2 py-1 rounded text-xs font-semibold">Verified</div>
                  )}
                </div>

                <h3 className="font-bold text-lg text-text-primary mb-1">{professional.name}</h3>
                <p className="text-primary text-sm font-semibold mb-2">{professional.role}</p>

                <div className="space-y-2 mb-4">
                  <div className="flex items-center gap-2 text-sm text-text-secondary">
                    <Award className="w-4 h-4" />
                    <span>{professional.specialization}</span>
                  </div>
                  <div className="flex items-center gap-2 text-sm text-text-secondary">
                    <MapPin className="w-4 h-4" />
                    <span>{professional.location}</span>
                  </div>
                </div>

                <div className="flex items-center justify-between mb-4 pb-4 border-b border-border">
                  <div className="flex items-center gap-2">
                    <Star className="w-4 h-4 fill-warning text-warning" />
                    <span className="font-semibold text-text-primary">{professional.rating}</span>
                    <span className="text-xs text-text-secondary">({professional.reviews})</span>
                  </div>
                  <span className="text-xs bg-accent px-2 py-1 rounded font-semibold text-primary">
                    {professional.badge}
                  </span>
                </div>

                <div className="flex items-center justify-between mb-4">
                  <div className="flex items-center gap-1">
                    <DollarSign className="w-4 h-4 text-text-secondary" />
                    <span className="font-semibold text-text-primary">{professional.hourlyRate}/hr</span>
                  </div>
                  <span className="text-xs text-text-secondary">{professional.experience} yrs exp.</span>
                </div>

                <Link
                  href={`/professionals/${professional.id}`}
                  className="w-full bg-primary text-white py-2 rounded-lg text-center font-semibold hover:bg-primary-light transition"
                >
                  View Profile
                </Link>
              </div>
            ))}
          </div>
        ) : (
          <div className="text-center py-12">
            <p className="text-text-secondary">No professionals found. Try adjusting your filters.</p>
          </div>
        )}
      </section>
    </div>
  )
}
