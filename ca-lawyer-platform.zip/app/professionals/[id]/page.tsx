"use client"
import { useState } from "react"
import { Star, MapPin, Award, DollarSign, Calendar, MessageSquare, Share2, Heart, Clock, Users } from "lucide-react"
import { useParams } from "next/navigation"

interface Professional {
  id: number
  name: string
  role: string
  specialization: string
  rating: number
  reviews: number
  hourlyRate: number
  location: string
  experience: number
  verified: boolean
  badge: string
  bio: string
  education: string[]
  certifications: string[]
  languages: string[]
  responseTime: string
  responseRate: string
}

const professionalsData: Record<number, Professional> = {
  1: {
    id: 1,
    name: "Rajesh Kumar",
    role: "Chartered Accountant",
    specialization: "Taxation & GST",
    rating: 4.9,
    reviews: 124,
    hourlyRate: 1500,
    location: "Mumbai, India",
    experience: 12,
    verified: true,
    badge: "Expert",
    bio: "Experienced Chartered Accountant with 12 years of expertise in taxation, GST compliance, and financial planning. Specialized in corporate tax strategy and regulatory compliance.",
    education: ["Bachelor of Commerce, Delhi University", "Chartered Accountant, ICAI"],
    certifications: ["GST Expert", "International Tax Advisor", "Financial Planning Professional"],
    languages: ["English", "Hindi", "Gujarati"],
    responseTime: "Within 1 hour",
    responseRate: "98%",
  },
  2: {
    id: 2,
    name: "Priya Singh",
    role: "Corporate Lawyer",
    specialization: "M&A & Contracts",
    rating: 4.8,
    reviews: 98,
    hourlyRate: 2000,
    location: "Delhi, India",
    experience: 10,
    verified: true,
    badge: "Top Rated",
    bio: "Expert Corporate Lawyer specializing in Mergers & Acquisitions, contract drafting, and corporate governance. Helped 200+ businesses with successful transactions.",
    education: ["Bachelor of Laws, National Law University", "Master of Laws, Delhi University"],
    certifications: ["M&A Expert", "Contract Law Specialist", "Corporate Governance"],
    languages: ["English", "Hindi"],
    responseTime: "Within 2 hours",
    responseRate: "96%",
  },
  3: {
    id: 3,
    name: "Amit Patel",
    role: "Tax Specialist CA",
    specialization: "International Tax",
    rating: 5.0,
    reviews: 67,
    hourlyRate: 2500,
    location: "Bangalore, India",
    experience: 15,
    verified: true,
    badge: "Expert",
    bio: "Senior Tax Specialist with 15 years of international tax experience. Expertise in BEPS, transfer pricing, and multi-jurisdictional tax planning.",
    education: ["Bachelor of Commerce, Bangalore University", "Chartered Accountant, ICAI", "Advanced Taxation Course"],
    certifications: ["International Tax Expert", "Transfer Pricing Specialist", "BEPS Advisor"],
    languages: ["English", "Hindi", "Kannada"],
    responseTime: "Within 30 minutes",
    responseRate: "99%",
  },
  4: {
    id: 4,
    name: "Neha Sharma",
    role: "Labor Lawyer",
    specialization: "Employment Law",
    rating: 4.7,
    reviews: 82,
    hourlyRate: 1800,
    location: "Pune, India",
    experience: 8,
    verified: true,
    badge: "Rising Star",
    bio: "Dedicated Labor and Employment Lawyer with 8 years of experience. Specialized in employee contracts, workplace disputes, and HR compliance.",
    education: ["Bachelor of Laws, Pune University", "Specialization in Employment Law"],
    certifications: ["Employment Law Expert", "HR Compliance Specialist"],
    languages: ["English", "Hindi", "Marathi"],
    responseTime: "Within 1 hour",
    responseRate: "97%",
  },
  5: {
    id: 5,
    name: "Vikram Singh",
    role: "Financial Advisor CA",
    specialization: "Financial Planning",
    rating: 4.6,
    reviews: 105,
    hourlyRate: 1200,
    location: "Hyderabad, India",
    experience: 9,
    verified: true,
    badge: "Popular",
    bio: "Trusted Financial Advisor helping individuals and businesses achieve their financial goals through strategic planning and investment advice.",
    education: ["Bachelor of Commerce, Hyderabad University", "Chartered Accountant, ICAI"],
    certifications: ["Financial Planning Expert", "Investment Advisor", "Wealth Management Specialist"],
    languages: ["English", "Hindi", "Telugu"],
    responseTime: "Within 2 hours",
    responseRate: "95%",
  },
  6: {
    id: 6,
    name: "Anaya Verma",
    role: "Real Estate Lawyer",
    specialization: "Property Law",
    rating: 4.8,
    reviews: 76,
    hourlyRate: 1600,
    location: "Chennai, India",
    experience: 11,
    verified: true,
    badge: "Trusted",
    bio: "Experienced Real Estate and Property Lawyer with 11 years of expertise in land transactions, property disputes, and real estate regulations.",
    education: ["Bachelor of Laws, Chennai University", "Master of Laws in Property Law"],
    certifications: ["Property Law Expert", "Real Estate Transaction Specialist"],
    languages: ["English", "Hindi", "Tamil"],
    responseTime: "Within 1.5 hours",
    responseRate: "96%",
  },
}

export default function ProfessionalProfilePage() {
  const params = useParams()
  const id = Number.parseInt(params?.id as string) || 1
  const professional = professionalsData[id] || professionalsData[1]

  const [isFavorited, setIsFavorited] = useState(false)
  const [showBooking, setShowBooking] = useState(false)

  return (
    <div className="min-h-screen bg-background-light">
      {/* Profile Header */}
      <section className="bg-white border-b border-border">
        <div className="max-w-5xl mx-auto px-4 sm:px-6 lg:px-8 py-8">
          <div className="flex flex-col md:flex-row gap-8">
            {/* Avatar and Basic Info */}
            <div className="flex-shrink-0">
              <div className="w-32 h-32 bg-gradient-to-br from-primary to-primary-light rounded-lg flex items-center justify-center text-white font-bold text-5xl shadow-lg">
                {professional.name.charAt(0)}
              </div>
            </div>

            <div className="flex-1">
              <div className="flex items-start justify-between mb-2">
                <div>
                  <h1 className="text-3xl font-bold text-text-primary">{professional.name}</h1>
                  <p className="text-lg text-primary font-semibold mt-1">{professional.role}</p>
                </div>
                {professional.verified && (
                  <div className="bg-success text-white px-3 py-1 rounded-lg text-sm font-semibold">✓ Verified</div>
                )}
              </div>

              <p className="text-text-secondary mb-4">{professional.specialization}</p>

              <div className="flex flex-wrap gap-4 mb-4">
                <div className="flex items-center gap-2">
                  <Star className="w-5 h-5 fill-warning text-warning" />
                  <span className="font-semibold text-text-primary">{professional.rating}</span>
                  <span className="text-text-secondary">({professional.reviews} reviews)</span>
                </div>
                <div className="flex items-center gap-2 text-text-secondary">
                  <MapPin className="w-5 h-5" />
                  <span>{professional.location}</span>
                </div>
                <div className="flex items-center gap-2 text-text-secondary">
                  <Award className="w-5 h-5" />
                  <span>{professional.experience} years experience</span>
                </div>
              </div>

              <div className="flex flex-wrap gap-3">
                <button
                  onClick={() => setShowBooking(true)}
                  className="flex items-center gap-2 bg-primary text-white px-6 py-2 rounded-lg font-semibold hover:bg-primary-light transition"
                >
                  <Calendar className="w-5 h-5" />
                  Book Session
                </button>
                <button className="flex items-center gap-2 border border-border px-6 py-2 rounded-lg font-semibold hover:bg-background-light transition">
                  <MessageSquare className="w-5 h-5" />
                  Message
                </button>
                <button
                  onClick={() => setIsFavorited(!isFavorited)}
                  className={`flex items-center gap-2 border border-border px-4 py-2 rounded-lg transition ${
                    isFavorited ? "bg-warning/10 border-warning" : ""
                  }`}
                >
                  <Heart className={`w-5 h-5 ${isFavorited ? "fill-warning text-warning" : ""}`} />
                </button>
                <button className="flex items-center gap-2 border border-border px-4 py-2 rounded-lg hover:bg-background-light transition">
                  <Share2 className="w-5 h-5" />
                </button>
              </div>
            </div>

            {/* Rate Card */}
            <div className="bg-background-light p-6 rounded-lg border border-border h-fit">
              <div className="mb-4">
                <span className="text-text-secondary text-sm">Hourly Rate</span>
                <div className="flex items-center gap-2 mt-1">
                  <DollarSign className="w-5 h-5 text-primary" />
                  <span className="text-2xl font-bold text-text-primary">{professional.hourlyRate}</span>
                </div>
              </div>
              <div className="space-y-2 text-sm">
                <div className="flex items-center gap-2 text-text-secondary">
                  <Clock className="w-4 h-4" />
                  <span>{professional.responseTime}</span>
                </div>
                <div className="flex items-center gap-2 text-text-secondary">
                  <Users className="w-4 h-4" />
                  <span>{professional.responseRate} response rate</span>
                </div>
              </div>
            </div>
          </div>
        </div>
      </section>

      {/* About Section */}
      <section className="max-w-5xl mx-auto px-4 sm:px-6 lg:px-8 py-12">
        <div className="grid grid-cols-1 lg:grid-cols-3 gap-8">
          {/* Main Content */}
          <div className="lg:col-span-2 space-y-8">
            {/* Bio */}
            <div>
              <h2 className="text-2xl font-bold text-text-primary mb-4">About {professional.name}</h2>
              <p className="text-text-secondary leading-relaxed">{professional.bio}</p>
            </div>

            {/* Education */}
            <div>
              <h3 className="text-xl font-bold text-text-primary mb-4">Education</h3>
              <ul className="space-y-2">
                {professional.education.map((edu, i) => (
                  <li key={i} className="flex items-start gap-3">
                    <div className="w-2 h-2 bg-primary rounded-full mt-2 flex-shrink-0" />
                    <span className="text-text-secondary">{edu}</span>
                  </li>
                ))}
              </ul>
            </div>

            {/* Certifications */}
            <div>
              <h3 className="text-xl font-bold text-text-primary mb-4">Certifications & Specializations</h3>
              <div className="flex flex-wrap gap-2">
                {professional.certifications.map((cert, i) => (
                  <span key={i} className="bg-primary/10 text-primary px-3 py-1 rounded-full text-sm font-semibold">
                    {cert}
                  </span>
                ))}
              </div>
            </div>

            {/* Languages */}
            <div>
              <h3 className="text-xl font-bold text-text-primary mb-4">Languages</h3>
              <div className="flex flex-wrap gap-2">
                {professional.languages.map((lang, i) => (
                  <span key={i} className="bg-background-light border border-border px-3 py-1 rounded-lg text-sm">
                    {lang}
                  </span>
                ))}
              </div>
            </div>
          </div>

          {/* Sidebar */}
          <div className="space-y-6">
            {/* Quick Stats */}
            <div className="bg-white rounded-lg border border-border p-6 space-y-4">
              <h3 className="font-bold text-text-primary">Quick Stats</h3>
              <div className="space-y-3">
                <div>
                  <span className="text-xs text-text-secondary uppercase font-semibold">Success Rate</span>
                  <div className="w-full bg-background-light rounded-full h-2 mt-1">
                    <div className="bg-success h-2 rounded-full" style={{ width: "95%" }} />
                  </div>
                  <span className="text-sm font-semibold text-text-primary mt-1 block">95%</span>
                </div>
                <div>
                  <span className="text-xs text-text-secondary uppercase font-semibold">Completed Sessions</span>
                  <span className="text-2xl font-bold text-text-primary block mt-1">
                    {professional.reviews * 10 + Math.floor(Math.random() * 100)}
                  </span>
                </div>
              </div>
            </div>

            {/* Availability */}
            <div className="bg-white rounded-lg border border-border p-6">
              <h3 className="font-bold text-text-primary mb-4">Availability</h3>
              <div className="space-y-2 text-sm">
                <div className="flex justify-between">
                  <span className="text-text-secondary">Response Time</span>
                  <span className="font-semibold text-text-primary">{professional.responseTime}</span>
                </div>
                <div className="flex justify-between">
                  <span className="text-text-secondary">Timezone</span>
                  <span className="font-semibold text-text-primary">IST (UTC+5:30)</span>
                </div>
                <div className="flex justify-between">
                  <span className="text-text-secondary">Member Since</span>
                  <span className="font-semibold text-text-primary">2020</span>
                </div>
              </div>
            </div>
          </div>
        </div>
      </section>

      {/* Reviews Section */}
      <section className="max-w-5xl mx-auto px-4 sm:px-6 lg:px-8 py-12 border-t border-border">
        <h2 className="text-2xl font-bold text-text-primary mb-8">Client Reviews</h2>
        <div className="space-y-6">
          {[
            {
              name: "Ajay Chopra",
              rating: 5,
              text: "Excellent service! Rajesh provided clear guidance on my GST compliance. Highly recommended.",
              date: "2 weeks ago",
            },
            {
              name: "Meera Desai",
              rating: 5,
              text: "Very professional and knowledgeable. Helped me understand complex tax concepts easily.",
              date: "1 month ago",
            },
            {
              name: "Suresh Kumar",
              rating: 4,
              text: "Great expertise and helpful insights. Would definitely consult again.",
              date: "2 months ago",
            },
          ].map((review, i) => (
            <div key={i} className="bg-white rounded-lg border border-border p-6">
              <div className="flex items-start justify-between mb-2">
                <h4 className="font-semibold text-text-primary">{review.name}</h4>
                <span className="text-xs text-text-secondary">{review.date}</span>
              </div>
              <div className="flex gap-1 mb-2">
                {Array(review.rating)
                  .fill(0)
                  .map((_, i) => (
                    <Star key={i} className="w-4 h-4 fill-warning text-warning" />
                  ))}
              </div>
              <p className="text-text-secondary">{review.text}</p>
            </div>
          ))}
        </div>
      </section>

      {/* Booking Modal */}
      {showBooking && (
        <div className="fixed inset-0 bg-black/50 z-50 flex items-end sm:items-center justify-center p-4">
          <div className="bg-white rounded-t-2xl sm:rounded-lg w-full sm:max-w-md p-6 shadow-lg">
            <h2 className="text-2xl font-bold text-text-primary mb-4">Book a Session</h2>
            <div className="space-y-4">
              <div>
                <label className="block text-sm font-semibold text-text-primary mb-2">Preferred Date</label>
                <input type="date" className="w-full px-4 py-2 border border-border rounded-lg" />
              </div>
              <div>
                <label className="block text-sm font-semibold text-text-primary mb-2">Preferred Time</label>
                <input type="time" className="w-full px-4 py-2 border border-border rounded-lg" />
              </div>
              <div>
                <label className="block text-sm font-semibold text-text-primary mb-2">Duration</label>
                <select className="w-full px-4 py-2 border border-border rounded-lg">
                  <option>30 minutes</option>
                  <option>1 hour</option>
                  <option>2 hours</option>
                </select>
              </div>
              <div>
                <label className="block text-sm font-semibold text-text-primary mb-2">Your Inquiry</label>
                <textarea
                  className="w-full px-4 py-2 border border-border rounded-lg h-24"
                  placeholder="Describe your issue or question..."
                />
              </div>
              <div className="flex gap-3 pt-4">
                <button
                  onClick={() => setShowBooking(false)}
                  className="flex-1 px-4 py-2 border border-border rounded-lg font-semibold hover:bg-background-light transition"
                >
                  Cancel
                </button>
                <button className="flex-1 px-4 py-2 bg-primary text-white rounded-lg font-semibold hover:bg-primary-light transition">
                  Continue
                </button>
              </div>
            </div>
          </div>
        </div>
      )}
    </div>
  )
}
